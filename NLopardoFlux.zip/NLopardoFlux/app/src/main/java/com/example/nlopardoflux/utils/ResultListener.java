package com.example.nlopardoflux.utils;

public interface ResultListener<T> {
    public void finish(T t);
}
