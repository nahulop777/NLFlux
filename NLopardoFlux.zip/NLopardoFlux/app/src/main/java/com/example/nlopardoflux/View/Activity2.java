package com.example.nlopardoflux.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.nlopardoflux.R;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
    }
}
