package com.example.nlopardoflux.Model;

import com.example.nlopardoflux.Model.User;

import java.util.List;

public class UserContainer {

    private List<User> data;

    public UserContainer(){

    }

    public UserContainer (List<User> data){
        this.data =data;

    }

    public List<User> getData() {
        return data;
    }

    public void setData(List<User> data) {
        this.data = data;
    }
}
